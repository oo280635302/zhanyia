-- Skill_213003702 
-- Generate By xNodeExporter 
-- Note: 熔岩喷发2级，对所有敌方单位造成1伤害，生成伤害次数+2个“活体熔岩”（幻影）至手牌


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.Their
card.affectedTargetFilter = CardCommon.TargetFilter.AllUnit
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 DamageAction
local action1 = DamageAction.New(CardCommon.TargetCamp.Their,CardCommon.TargetFilter.AllUnit,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return 1+self.variable["magicStrength"]
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "SimpleDamageViewAction" 


-- action2 ConstNumberRepeaterAction
local action2 = ConstNumberRepeaterAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return self.variable["damageCount"]+2
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "" 


-- action3 CreateCardAction
local action3 = CreateCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.All,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Use
action3.va1Type = CardCommon.CardActionValueType.BaseId
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self:ToUserCardCfgId(2120007)
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "" 


-- action4 AddAffixAction
local action4 = AddAffixAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.Use
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return 81001101
end 

action4.getVa2 = function(self) 
	return -1 
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "" 


-- action5 PutCardToAction
local action5 = PutCardToAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action4:AddNextAction(action5)

action5.cardData = card
action5.triggerId = CardCommon.CardTrigger.Use
action5.va1Type = CardCommon.CardActionValueType.Normal
action5.va2Type = CardCommon.CardActionValueType.Normal
action5.va3Type = CardCommon.CardActionValueType.Normal
action5.getVa1 = function(self) 
	return 1
end 

action5.getVa2 = function(self) 
	return -1 
end 

action5.getVa3 = function(self) 
	return -1 
end 

action5.viewActionName = "PutCardInHandSimple" 
card:AddTrigger(trigger) 
return card