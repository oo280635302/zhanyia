-- Skill_263001301 
-- Generate By xNodeExporter 
-- Note: 灼烧1级，对目标造成2点伤害；


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitWithoutHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------OnCreate-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.OnCreate


-- action1 AddAffixAction
local action1 = AddAffixAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.OnCreate
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return 81001401
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 
card:AddTrigger(trigger) 
-----------------------Discard-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Discard


-- action2 DamageAction
local action2 = DamageAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Hero,1) 
trigger:AddAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Discard
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return 1
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "SimpleDamageViewAction" 
card:AddTrigger(trigger) 
return card