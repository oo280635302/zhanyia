-- MonsterSkill_363000901 
-- Generate By xNodeExporter 
-- Note: 愧疚注入：在玩家手牌中插入一张“横生愧疚”（幻影）


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitWithoutHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 CreateCardAction
local action1 = CreateCardAction.New(CardCommon.TargetCamp.Their,CardCommon.TargetFilter.Hero,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return 263001301
end 

action1.getVa2 = function(self) 
	return "real"
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 PutCardToAction
local action2 = PutCardToAction.New(CardCommon.TargetCamp.Their,CardCommon.TargetFilter.LastAction,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return 1
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "PutCardInHandSimple" 
card:AddTrigger(trigger) 
return card