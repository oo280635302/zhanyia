-- Skill_213006304 
-- Generate By xNodeExporter 
-- Note: 熔铸护甲3级，牺牲己方所有“活体熔岩”，使目标获得“活体熔岩”数+3的护甲


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitAndHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.AllUnit
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 PickCardAction
local action1 = PickCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.AllUnit,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return self.variable["baseId"]==2120007
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 SacrificeAction
local action2 = SacrificeAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return -1 
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "SimpleDieViewAction" 


-- action3 ShieldAction
local action3 = ShieldAction.New(CardCommon.TargetCamp.SelectTarget,CardCommon.TargetFilter.SelectedUnitAndHero,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Use
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self.variable["sacrificeCount"]+3
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "SimpleUpdateHud" 
card:AddTrigger(trigger) 
return card