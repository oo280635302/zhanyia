-- Skill_213005302 
-- Generate By xNodeExporter 
-- Note: 生命之火1级，对所有己方单位造成1治疗，并使其单位生命值加倍，获得2层缴械，消耗


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.Our
card.affectedTargetFilter = CardCommon.TargetFilter.AllUnit
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 RecoverHpAction
local action1 = RecoverHpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.AllUnit,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return 1+self.variable["magicStrength"]
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 MaxHpAction
local action2 = MaxHpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.AllUnit,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return 2*self.variable["maxHp"]
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "" 


-- action3 HpAction
local action3 = HpAction.New(CardCommon.TargetCamp.All,CardCommon.TargetFilter.AllUnit,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Use
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return 2*self.variable["hp"]
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "SimpleUpdateHud" 


-- action4 AddBuffAction
local action4 = AddBuffAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.AllUnit,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.Use
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return 81101401
end 

action4.getVa2 = function(self) 
	return 1
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "CurseViewAction" 
card:AddTrigger(trigger) 
-----------------------OnCreate-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.OnCreate


-- action5 AddAffixAction
local action5 = AddAffixAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
trigger:AddAction(action5)

action5.cardData = card
action5.triggerId = CardCommon.CardTrigger.OnCreate
action5.va1Type = CardCommon.CardActionValueType.Normal
action5.va2Type = CardCommon.CardActionValueType.Normal
action5.va3Type = CardCommon.CardActionValueType.Normal
action5.getVa1 = function(self) 
	return 81000201
end 

action5.getVa2 = function(self) 
	return -1 
end 

action5.getVa3 = function(self) 
	return -1 
end 

action5.viewActionName = "" 
card:AddTrigger(trigger) 
return card