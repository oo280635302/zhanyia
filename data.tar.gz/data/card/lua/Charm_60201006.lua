-- Charm_60201006 
-- Generate By xNodeExporter 
-- Note: 活力:魔咒,生命+1


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitWithoutHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------OnCreate-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.OnCreate


-- action1 MaxHpAction
local action1 = MaxHpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.OnCreate
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return self.variable["maxHp"]+2
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 HpAction
local action2 = HpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.OnCreate
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return self.variable["hp"]+2
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "" 


-- action3 AtkAction
local action3 = AtkAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.OnCreate
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self.variable["atk"]+1
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "" 


-- action4 CostAction
local action4 = CostAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.OnCreate
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return self.variable["cost"]+1
end 

action4.getVa2 = function(self) 
	return -1 
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "" 
card:AddTrigger(trigger) 
return card