-- Unit_212000803 
-- Generate By xNodeExporter 
-- Note: 食火者3级，攻击前：吞食本行“活体熔岩”，攻击+2，护甲+2


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Unit
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------BeforeAttack-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.BeforeAttack


-- action1 PickCardAction
local action1 = PickCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.SelfRowUnit,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.BeforeAttack
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return self.variable["baseId"]==2120007
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 SacrificeAction
local action2 = SacrificeAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.BeforeAttack
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return -1 
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "SacrificeInBattle" 


-- card branch 
local branch2 = CardBranch.New(1) 
action2:AddNextAction(branch2)

branch2.cardData = card
branch2.triggerId = CardCommon.CardTrigger.BeforeAttack
branch2:AddConditionBranch("EnvVariableEqual","pickCardNum",1,"")


-- action3 AtkAction
local action3 = AtkAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
branch2:AddNextPassActions(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.BeforeAttack
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self.variable["atk"]+2
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "UpdateHudInBattle" 


-- action4 ShieldAction
local action4 = ShieldAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.BeforeAttack
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return 2
end 

action4.getVa2 = function(self) 
	return -1 
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "UpdateHudInBattle" 
card:AddTrigger(trigger) 
-----------------------Attack-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Attack


-- action5 DamageAction
local action5 = DamageAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Blocker,1) 
trigger:AddAction(action5)

action5.cardData = card
action5.triggerId = CardCommon.CardTrigger.Attack
action5.va1Type = CardCommon.CardActionValueType.Normal
action5.va2Type = CardCommon.CardActionValueType.Normal
action5.va3Type = CardCommon.CardActionValueType.Normal
action5.getVa1 = function(self) 
	return self.variable["atk"]
end 

action5.getVa2 = function(self) 
	return -1 
end 

action5.getVa3 = function(self) 
	return -1 
end 

action5.viewActionName = "SimpleUpdateHud" 
card:AddTrigger(trigger) 
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action6 ToSlotAction
local action6 = ToSlotAction.New(CardCommon.TargetCamp.SelectTarget,CardCommon.TargetFilter.SelectedSlot,1) 
trigger:AddAction(action6)

action6.cardData = card
action6.triggerId = CardCommon.CardTrigger.Use
action6.va1Type = CardCommon.CardActionValueType.Normal
action6.va2Type = CardCommon.CardActionValueType.Normal
action6.va3Type = CardCommon.CardActionValueType.Normal
action6.getVa1 = function(self) 
	return -1 
end 

action6.getVa2 = function(self) 
	return -1 
end 

action6.getVa3 = function(self) 
	return -1 
end 

action6.viewActionName = "ToSlotViewAction" 
card:AddTrigger(trigger) 
return card