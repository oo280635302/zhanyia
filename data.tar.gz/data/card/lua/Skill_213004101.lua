-- Skill_213004101 
-- Generate By xNodeExporter 
-- Note: 恶魔之书1级，复活墓地中随机1名恶魔单位至目标位置，并使其获得+1/+2，消耗


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.Our
card.affectedTargetFilter = CardCommon.TargetFilter.ExhaustHeap
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 PickCardAction
local action1 = PickCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.ExhaustHeap,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return self.variable["race"] == 101
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 RandomOneTargetAction
local action2 = RandomOneTargetAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return -1 
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "" 


-- action3 MaxHpAction
local action3 = MaxHpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Use
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self.variable["hp"]+2
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "" 


-- action4 HpAction
local action4 = HpAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.Use
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return self.variable["hp"]+2
end 

action4.getVa2 = function(self) 
	return -1 
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "" 


-- action5 AutoUseAction
local action5 = AutoUseAction.New(CardCommon.TargetCamp.All,CardCommon.TargetFilter.LastAction,1) 
action4:AddNextAction(action5)

action5.cardData = card
action5.triggerId = CardCommon.CardTrigger.Use
action5.va1Type = CardCommon.CardActionValueType.Normal
action5.va2Type = CardCommon.CardActionValueType.Normal
action5.va3Type = CardCommon.CardActionValueType.Normal
action5.getVa1 = function(self) 
	return -1 
end 

action5.getVa2 = function(self) 
	return -1 
end 

action5.getVa3 = function(self) 
	return -1 
end 

action5.viewActionName = "" 


-- action6 AtkAction
local action6 = AtkAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action2:AddNextAction(action6)

action6.cardData = card
action6.triggerId = CardCommon.CardTrigger.Use
action6.va1Type = CardCommon.CardActionValueType.Normal
action6.va2Type = CardCommon.CardActionValueType.Normal
action6.va3Type = CardCommon.CardActionValueType.Normal
action6.getVa1 = function(self) 
	return self.variable["atk"]+1
end 

action6.getVa2 = function(self) 
	return -1 
end 

action6.getVa3 = function(self) 
	return -1 
end 

action6.viewActionName = "" 
card:AddTrigger(trigger) 
-----------------------OnCreate-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.OnCreate


-- action7 AddAffixAction
local action7 = AddAffixAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
trigger:AddAction(action7)

action7.cardData = card
action7.triggerId = CardCommon.CardTrigger.OnCreate
action7.va1Type = CardCommon.CardActionValueType.Normal
action7.va2Type = CardCommon.CardActionValueType.Normal
action7.va3Type = CardCommon.CardActionValueType.Normal
action7.getVa1 = function(self) 
	return 81000201
end 

action7.getVa2 = function(self) 
	return -1 
end 

action7.getVa3 = function(self) 
	return -1 
end 

action7.viewActionName = "" 
card:AddTrigger(trigger) 
return card