-- Hero_210000201 
-- Generate By xNodeExporter 
-- Note: 游猎者1级：能力：血之鼓舞1级


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Unit
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------Counter-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Counter


-- action1 DamageAction
local action1 = DamageAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Custom,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Counter
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return self.variable["atk"]
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "HeroCounterAttack" 
card:AddTrigger(trigger) 
return card