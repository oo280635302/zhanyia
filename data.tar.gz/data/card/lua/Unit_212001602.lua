-- Unit_212001602 
-- Generate By xNodeExporter 
-- Note: 恶魔战士2级，杀戮：攻击力+3


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Unit
card.targetCamp = CardCommon.CardUseTargetCamp.Our
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedSlot
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 ToSlotAction
local action1 = ToSlotAction.New(CardCommon.TargetCamp.SelectTarget,CardCommon.TargetFilter.SelectedSlot,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return -1 
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "ToSlotViewAction" 
card:AddTrigger(trigger) 
-----------------------Attack-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Attack


-- action2 DamageAction
local action2 = DamageAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Blocker,1) 
trigger:AddAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Attack
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return self.variable["atk"]
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "NormalMeleeUnit" 
card:AddTrigger(trigger) 
-----------------------Slaughter-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Slaughter


-- action3 AtkAction
local action3 = AtkAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.Self,1) 
trigger:AddAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Slaughter
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return self.variable["atk"]+3
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "SimpleUpdateHud" 
card:AddTrigger(trigger) 
return card