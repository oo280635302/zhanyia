-- Skill_203001202 
-- Generate By xNodeExporter 
-- Note: 禁言锁链2级，对目标施加1层沉默


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitWithoutHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.SelectTarget
card.affectedTargetFilter = CardCommon.TargetFilter.SelectedUnitWithoutHero
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return true 
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = true
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 AddBuffAction
local action1 = AddBuffAction.New(CardCommon.TargetCamp.SelectTarget,CardCommon.TargetFilter.SelectedUnitWithoutHero,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return 81100801
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "CurseViewAction" 
card:AddTrigger(trigger) 
return card