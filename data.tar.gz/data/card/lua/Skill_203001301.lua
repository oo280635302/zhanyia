-- Skill_203001301 
-- Generate By xNodeExporter 
-- Note: 凡者转生1级：选择弃置一张手牌至墓地，之后使墓地中最多2个随机Common单位洗回牌堆


require("CardData/CardActionCommon") 
require("CardData/CardData") 
require("CardData/CardTrigger") 
local card = nil 
local node = nil 
local trigger = nil 
local action = nil 
local childAction = nil 
local viewAction = nil 
card = CardData.New() 
card.cardType = CardCommon.CardType.Magic
card.targetCamp = CardCommon.CardUseTargetCamp.All
card.targetFilter = CardCommon.CardUseTargetFilter.SelectedUnitWithoutHero
card.useLimitType = CardCommon.CardActionValueType.Normal
card.useLimit = function(variable) 
	return true 
end 
card.affectedTargetCamp = CardCommon.TargetCamp.All
card.affectedTargetFilter = CardCommon.TargetFilter.All
card.affectedLimitType = CardCommon.CardActionValueType.Normal
card.affectedLimit = function(variable) 
	return "1==2"
end 
card.costFunc = function(variable) 
	return variable["cost"] 
end 
card.needArrow = false
-----------------------Use-----------------------
trigger = CardTrigger.New() 
trigger.name = CardCommon.CardTrigger.Use


-- action1 PickCardAction
local action1 = PickCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.HandHeap,1) 
trigger:AddAction(action1)

action1.cardData = card
action1.triggerId = CardCommon.CardTrigger.Use
action1.va1Type = CardCommon.CardActionValueType.Normal
action1.va2Type = CardCommon.CardActionValueType.Normal
action1.va3Type = CardCommon.CardActionValueType.Normal
action1.getVa1 = function(self) 
	return -1 
end 

action1.getVa2 = function(self) 
	return -1 
end 

action1.getVa3 = function(self) 
	return -1 
end 

action1.viewActionName = "" 


-- action2 ManualFilterCardAction
local action2 = ManualFilterCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action1:AddNextAction(action2)

action2.cardData = card
action2.triggerId = CardCommon.CardTrigger.Use
action2.va1Type = CardCommon.CardActionValueType.Normal
action2.va2Type = CardCommon.CardActionValueType.Normal
action2.va3Type = CardCommon.CardActionValueType.Normal
action2.getVa1 = function(self) 
	return 1
end 

action2.getVa2 = function(self) 
	return -1 
end 

action2.getVa3 = function(self) 
	return -1 
end 

action2.viewActionName = "" 


-- action3 PutCardToAction
local action3 = PutCardToAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action2:AddNextAction(action3)

action3.cardData = card
action3.triggerId = CardCommon.CardTrigger.Use
action3.va1Type = CardCommon.CardActionValueType.Normal
action3.va2Type = CardCommon.CardActionValueType.Normal
action3.va3Type = CardCommon.CardActionValueType.Normal
action3.getVa1 = function(self) 
	return 2
end 

action3.getVa2 = function(self) 
	return -1 
end 

action3.getVa3 = function(self) 
	return -1 
end 

action3.viewActionName = "SimpleDropCardToExhaust" 


-- action4 ConstNumberRepeaterAction
local action4 = ConstNumberRepeaterAction.New(CardCommon.TargetCamp.All,CardCommon.TargetFilter.All,1) 
action3:AddNextAction(action4)

action4.cardData = card
action4.triggerId = CardCommon.CardTrigger.Use
action4.va1Type = CardCommon.CardActionValueType.Normal
action4.va2Type = CardCommon.CardActionValueType.Normal
action4.va3Type = CardCommon.CardActionValueType.Normal
action4.getVa1 = function(self) 
	return 2
end 

action4.getVa2 = function(self) 
	return -1 
end 

action4.getVa3 = function(self) 
	return -1 
end 

action4.viewActionName = "" 


-- action5 PickCardAction
local action5 = PickCardAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.ExhaustHeap,1) 
action4:AddNextAction(action5)

action5.cardData = card
action5.triggerId = CardCommon.CardTrigger.Use
action5.va1Type = CardCommon.CardActionValueType.Normal
action5.va2Type = CardCommon.CardActionValueType.Normal
action5.va3Type = CardCommon.CardActionValueType.Normal
action5.getVa1 = function(self) 
	return self.variable["rarity"] == 1 and self.variable["isUnit"] == true
end 

action5.getVa2 = function(self) 
	return -1 
end 

action5.getVa3 = function(self) 
	return -1 
end 

action5.viewActionName = "" 


-- action6 RandomOneTargetAction
local action6 = RandomOneTargetAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action5:AddNextAction(action6)

action6.cardData = card
action6.triggerId = CardCommon.CardTrigger.Use
action6.va1Type = CardCommon.CardActionValueType.Normal
action6.va2Type = CardCommon.CardActionValueType.Normal
action6.va3Type = CardCommon.CardActionValueType.Normal
action6.getVa1 = function(self) 
	return -1 
end 

action6.getVa2 = function(self) 
	return -1 
end 

action6.getVa3 = function(self) 
	return -1 
end 

action6.viewActionName = "" 


-- action7 PutCardToAction
local action7 = PutCardToAction.New(CardCommon.TargetCamp.Our,CardCommon.TargetFilter.LastAction,1) 
action6:AddNextAction(action7)

action7.cardData = card
action7.triggerId = CardCommon.CardTrigger.Use
action7.va1Type = CardCommon.CardActionValueType.Normal
action7.va2Type = CardCommon.CardActionValueType.Normal
action7.va3Type = CardCommon.CardActionValueType.Normal
action7.getVa1 = function(self) 
	return 3
end 

action7.getVa2 = function(self) 
	return -1 
end 

action7.getVa3 = function(self) 
	return -1 
end 

action7.viewActionName = "PutCardInHandSimple" 
card:AddTrigger(trigger) 
return card