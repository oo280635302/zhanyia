## 枚举

### 类型枚举

```cs
public enum AdventureEventNodeType
{
    AdventureEventStart = 1,//全局只有一个，用于整个流程开始，不做任何行为
    AdventureEventEnd = 2,//全局只有一个，用于整个流程结束，不做任何行为
    AdventureEventHandle = 3,//用于多个选项得选择
    AdventureEventAction = 4,//用于行为触发，与 AdventureEventActionType 关联
}
```



### 行为枚举

主要用于标记行为类型

```cs
public enum AdventureEventActionType 
{
    Event = 1,
    Fun = 2,
    AddHP = 3,
    ReduceHP = 4,
    DeductGold = 5,
    Gain = 6,
}
```

## 数据结构

### 1. 通用节点结构

* Type：Lua中为 AdventureEventNodeType 对应的字段，Jason 为 AdventureEventNodeType 对应的整数
* Index：节点对应的索引， Lua从 1 开始，Jason 从0开始
* Pre ： 保留，暂时无用
* Next：下一步关联的所有节点索引值，结束节点（AdventureEventEnd）没有该字段

#### 1.1 选择节点

包含多个选择内容 **Items**，每个Item内容中包含一个 Next 内容，指向下一步关联的所有节点索引值。

若**Items**没有内容则使用节点中的**Next**作为唯一选择的节点索引指向。



