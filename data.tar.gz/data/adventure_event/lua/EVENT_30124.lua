-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30110", Content = "Event_Result_30110_1", Label = "Event_Option_30121_2", Next = {3,}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_CostDice", Label = "Event_Option_30124_2", Tip = "Event_UseDice", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughDice", ConditionType = AdventureConditionType.DICE, ConditionParam1 = 1, ConditionParam2 = 999, Next = {3,7,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Combat", Label = "Event_Option_30124_1", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {5,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30110", Content = "Event_Result_30124_2", Label = "Event_Confirm", Next = {8,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30110", Content = "Event_Result_30124_1", Label = "Event_Battle", Next = {4,6,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventAction
local node_6 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 6, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1040603"}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 1, ActionType = AdventureEventActionType.ReduceDice, Param = "1"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventRandomAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 8, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_8)
-- Item Count : 3
local node_8_0 = {Weight = 40, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {9,12,}}
table.insert(node_8.Items, node_8_0)
local node_8_1 = {Weight = 40, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {10,12,}}
table.insert(node_8.Items, node_8_1)
local node_8_2 = {Weight = 20, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {11,12,}}
table.insert(node_8.Items, node_8_2)

-- Index : 9, Type : AdventureEventAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 9, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30124"}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30125"}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30126"}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventEnd
local node_12 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 12, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_12)

return nodes
