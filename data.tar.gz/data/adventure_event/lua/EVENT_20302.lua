-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20302", Content = "Event_Text_20302_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_CopyCard", Label = "Event_Option_20302_1", Tip = "Event_CopyCard", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,4,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Refuse", Tip = "Event_Leave", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {14,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "50303"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20302", Content = "Event_Text_20302_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_4)
-- Item Count : 2
local node_4_0 = {Icon = "UI/Adventure/icon_Event_CopyCard", Label = "Event_Option_20302_2", Tip = "Event_CopyCard", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 30, ConditionParam2 = 999, Next = {5,7,12,}}
table.insert(node_4.Items, node_4_0)
local node_4_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Refuse", Tip = "Event_Leave", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_4.Items, node_4_1)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "50303"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20302", Content = "Event_Text_20302_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_7)
-- Item Count : 2
local node_7_0 = {Icon = "UI/Adventure/icon_Event_CopyCard", Label = "Event_Option_20302_4", Tip = "Event_CopyCard", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 50, ConditionParam2 = 999, Next = {8,10,13,}}
table.insert(node_7.Items, node_7_0)
local node_7_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Refuse", Tip = "Event_Leave", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {9,}}
table.insert(node_7.Items, node_7_1)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "50303"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventEnd
local node_9 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 9, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventHandle
local node_10 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 10, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20302", Content = "Event_Text_20302_4", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_10)
-- Item Count : 1
local node_10_0 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_Leave", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {11,}}
table.insert(node_10.Items, node_10_0)

-- Index : 11, Type : AdventureEventEnd
local node_11 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 11, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventAction
local node_12 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 12, Sort = 99, ActionType = AdventureEventActionType.ReduceTimedust, Param = "30"}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventAction
local node_13 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 13, Sort = 99, ActionType = AdventureEventActionType.ReduceTimedust, Param = "50"}
table.insert(nodes, node_13)

-- Index : 14, Type : AdventureEventEnd
local node_14 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 14, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_14)

return nodes
