-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "idle",  Title = "Event_Name_40101_1", Content = "Event_Text_40101_1", Label = "Event_Continue", Next = {9,}, Items = {}}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "alert",  Title = "Event_Name_40101_1", Content = "Event_Text_40101_3", Label = "Event_Continue", Next = {10,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = false,  Unit = "10001", UnitAction = "exciting",  Title = "Event_Name_40101_1", Content = "Event_Text_40101_5", Label = "Event_Continue", Next = {}, Items = {}}
table.insert(nodes, node_4)
-- Item Count : 2
local node_4_0 = {Icon = "", Label = "Event_Option_40101_3", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {7,}}
table.insert(node_4.Items, node_4_0)
local node_4_1 = {Icon = "", Label = "Event_Option_40101_4", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {8,}}
table.insert(node_4.Items, node_4_1)

-- Index : 5, Type : AdventureEventEnd
local node_5 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 5, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventAction
local node_6 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 6, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "exciting",  Title = "Event_Name_40101_1", Content = "Event_Result_40101_2", Label = "Event_Continue", Next = {5,11,}, Items = {}}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventHandle
local node_8 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 8, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "angry",  Title = "Event_Name_40101_1", Content = "Event_Result_40101_3", Label = "Event_Continue", Next = {5,11,}, Items = {}}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventHandle
local node_9 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 9, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "alert",  Title = "Event_Name_40101_1", Content = "Event_Text_40101_2", Label = "Event_Option_40101_1", Next = {3,}, Items = {}}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventHandle
local node_10 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 10, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "alert",  Title = "Event_Name_40101_1", Content = "Event_Text_40101_4", Label = "Event_Option_40101_2", Next = {4,}, Items = {}}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 1, ActionType = AdventureEventActionType.Event, Param = "40104"}
table.insert(nodes, node_11)

return nodes
