-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Text_40201_1", Label = "Event_Option_40201_1", Next = {6,}, Items = {}}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventEnd
local node_3 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 3, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 4, Sort = 99, ActionType = AdventureEventActionType.SetFlag, Param = "10001"}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

return nodes
