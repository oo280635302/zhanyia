-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30301", Content = "Event_Text_30301_1", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 4
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30301_1", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_Challenged", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 30001, ConditionParam2 = 0, Next = {3,6,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30301_2", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_Challenged", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 30002, ConditionParam2 = 0, Next = {4,6,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30301_3", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_Challenged", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 30003, ConditionParam2 = 0, Next = {5,6,}}
table.insert(node_2.Items, node_2_2)
local node_2_3 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30301_4", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_2.Items, node_2_3)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1041004"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 4, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1041104"}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1041204"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_7)

return nodes
