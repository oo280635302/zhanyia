-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30112", Content = "Event_Text_30112_1", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30112_1", Tip = "Event_Unknown", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughDice", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 1, ConditionParam2 = 999, Next = {5,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30112_2", Tip = "Event_Unknown", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30112", Content = "Event_Result_30112_2", Label = "Event_Leave", Next = {4,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30112", Content = "Event_Result_30112_1", Label = "Event_Battle", Next = {6,4,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventAction
local node_6 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 6, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1021102"}
table.insert(nodes, node_6)

return nodes
