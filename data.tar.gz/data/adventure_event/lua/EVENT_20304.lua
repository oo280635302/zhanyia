-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20304", Content = "Event_Text_20304_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 1
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Shop", Label = "Event_Option_20304_1", Tip = "Event_CharmShop", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,4,}}
table.insert(node_2.Items, node_2_0)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 99, ActionType = AdventureEventActionType.Shop, Param = "20304"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

return nodes
