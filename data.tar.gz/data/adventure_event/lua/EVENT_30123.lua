-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30123_1", Tip = "Event_UseTimedust", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 5, ConditionParam2 = 999, Next = {4,11,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_GiveUp", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {12,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_6", Label = "Event_Leave", Next = {7,5,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventRandomAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 4, Sort = 2, Next = {}, Items = {}}
table.insert(nodes, node_4)
-- Item Count : 2
local node_4_0 = {Weight = 10, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,}}
table.insert(node_4.Items, node_4_0)
local node_4_1 = {Weight = 90, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 20005, ConditionParam2 = 0, Next = {13,}}
table.insert(node_4.Items, node_4_1)

-- Index : 5, Type : AdventureEventEnd
local node_5 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 5, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventRandomAction
local node_6 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 6, Sort = 2, Next = {}, Items = {}}
table.insert(nodes, node_6)
-- Item Count : 2
local node_6_0 = {Weight = 20, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {14,}}
table.insert(node_6.Items, node_6_0)
local node_6_1 = {Weight = 80, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 20005, ConditionParam2 = 0, Next = {18,}}
table.insert(node_6.Items, node_6_1)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "15"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventRandomAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 9, Sort = 2, Next = {}, Items = {}}
table.insert(nodes, node_9)
-- Item Count : 2
local node_9_0 = {Weight = 35, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {19,}}
table.insert(node_9.Items, node_9_0)
local node_9_1 = {Weight = 65, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 20005, ConditionParam2 = 0, Next = {23,}}
table.insert(node_9.Items, node_9_1)

-- Index : 10, Type : AdventureEventRandomAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 10, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_10)
-- Item Count : 2
local node_10_0 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {24,}}
table.insert(node_10.Items, node_10_0)
local node_10_1 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 20005, ConditionParam2 = 0, Next = {28,}}
table.insert(node_10.Items, node_10_1)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "10"}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventEnd
local node_12 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 12, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventHandle
local node_13 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 13, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_13)
-- Item Count : 2
local node_13_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30123_2", Tip = "Event_UseTimedust", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 5, ConditionParam2 = 999, Next = {6,8,}}
table.insert(node_13.Items, node_13_0)
local node_13_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_GiveUp", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {5,}}
table.insert(node_13.Items, node_13_1)

-- Index : 14, Type : AdventureEventHandle
local node_14 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 14, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_6", Label = "Event_Leave", Next = {16,15,}, Items = {}}
table.insert(nodes, node_14)

-- Index : 15, Type : AdventureEventEnd
local node_15 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 15, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_15)

-- Index : 16, Type : AdventureEventAction
local node_16 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 16, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_16)

-- Index : 17, Type : AdventureEventAction
local node_17 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 17, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "20"}
table.insert(nodes, node_17)

-- Index : 18, Type : AdventureEventHandle
local node_18 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 18, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_3", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_18)
-- Item Count : 2
local node_18_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30123_3", Tip = "Event_UseTimedust", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 5, ConditionParam2 = 999, Next = {17,9,}}
table.insert(node_18.Items, node_18_0)
local node_18_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_GiveUp", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {15,}}
table.insert(node_18.Items, node_18_1)

-- Index : 19, Type : AdventureEventHandle
local node_19 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 19, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_6", Label = "Event_Leave", Next = {21,20,}, Items = {}}
table.insert(nodes, node_19)

-- Index : 20, Type : AdventureEventEnd
local node_20 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 20, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_20)

-- Index : 21, Type : AdventureEventAction
local node_21 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 21, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_21)

-- Index : 22, Type : AdventureEventAction
local node_22 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 22, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "25"}
table.insert(nodes, node_22)

-- Index : 23, Type : AdventureEventHandle
local node_23 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 23, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_23)
-- Item Count : 2
local node_23_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30123_4", Tip = "Event_UseTimedust", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 5, ConditionParam2 = 999, Next = {22,10,}}
table.insert(node_23.Items, node_23_0)
local node_23_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_GiveUp", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {20,}}
table.insert(node_23.Items, node_23_1)

-- Index : 24, Type : AdventureEventHandle
local node_24 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 24, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_6", Label = "Event_Leave", Next = {26,25,}, Items = {}}
table.insert(nodes, node_24)

-- Index : 25, Type : AdventureEventEnd
local node_25 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 25, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_25)

-- Index : 26, Type : AdventureEventAction
local node_26 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 26, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_26)

-- Index : 27, Type : AdventureEventAction
local node_27 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 27, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "30"}
table.insert(nodes, node_27)

-- Index : 28, Type : AdventureEventHandle
local node_28 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 28, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_3", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_28)
-- Item Count : 2
local node_28_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30123_5", Tip = "Event_UseTimedust", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 5, ConditionParam2 = 999, Next = {27,29,}}
table.insert(node_28.Items, node_28_0)
local node_28_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_GiveUp", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {25,}}
table.insert(node_28.Items, node_28_1)

-- Index : 29, Type : AdventureEventHandle
local node_29 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 29, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30123", Content = "Event_Text_30123_6", Label = "Event_Leave", Next = {31,30,}, Items = {}}
table.insert(nodes, node_29)

-- Index : 30, Type : AdventureEventEnd
local node_30 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 30, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_30)

-- Index : 31, Type : AdventureEventAction
local node_31 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 31, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_31)

return nodes
