-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30505", Content = "Event_Text_30505_1", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 3
local node_2_0 = {Icon = "UI/Adventure/icon_Event_GetRelic", Label = "Event_Option_30502_1", Tip = "Event_GainRelic", ItemType = AdventureEventItemType.NONE, CTip = "Event_ChoiceDark", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 30005, ConditionParam2 = 1, Next = {4,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_GetRelic", Label = "Event_Option_30502_2", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_ChoiceLight", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 30004, ConditionParam2 = 1, Next = {5,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_2.Items, node_2_2)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1040901"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30501", Content = "Event_Result_30502_1", Label = "Event_Confirm", Next = {6,7,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30501", Content = "Event_Result_30502_2", Label = "Event_Battle", Next = {6,3,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30118"}
table.insert(nodes, node_7)

return nodes
