-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {3,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventEnd
local node_2 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 2, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = false,  Unit = "10006", UnitAction = "death",  Title = "Event_Name_40501_1", Content = "Event_Text_40502_1", Label = "Event_Option_40502_1", Next = {5,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 4, Sort = 99, ActionType = AdventureEventActionType.SetFlag, Param = "10005"}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = false,  Unit = "10006", UnitAction = "idle",  Title = "Event_Name_40501_1", Content = "Event_Text_40502_2", Label = "Event_Continue", Next = {7,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = false,  Unit = "10006", UnitAction = "cheer",  Title = "Event_Name_40501_1", Content = "Event_Text_40502_4", Label = "Event_Leave", Next = {4,2,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 99, ShowHead = true,  Unit = "10006", UnitAction = "idle",  Title = "Event_Name_40501_1", Content = "Event_Text_40502_3", Label = "Event_Option_40502_2", Next = {6,}, Items = {}}
table.insert(nodes, node_7)

return nodes
