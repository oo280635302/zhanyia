-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_1", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30119_1", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {3,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {4,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventRandomAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 3, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_3)
-- Item Count : 2
local node_3_0 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {25,}}
table.insert(node_3.Items, node_3_0)
local node_3_1 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_3.Items, node_3_1)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_2", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_5)
-- Item Count : 2
local node_5_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30119_3", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {9,}}
table.insert(node_5.Items, node_5_0)
local node_5_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {8,}}
table.insert(node_5.Items, node_5_1)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_5", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_6)
-- Item Count : 1
local node_6_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Battle", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {7,24,}}
table.insert(node_6.Items, node_6_0)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1020503"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventEnd
local node_8 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 8, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventRandomAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 9, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_9)
-- Item Count : 2
local node_9_0 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {26,}}
table.insert(node_9.Items, node_9_0)
local node_9_1 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {11,}}
table.insert(node_9.Items, node_9_1)

-- Index : 10, Type : AdventureEventHandle
local node_10 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 10, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_3", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_10)
-- Item Count : 2
local node_10_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30119_5", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {14,}}
table.insert(node_10.Items, node_10_0)
local node_10_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {13,}}
table.insert(node_10.Items, node_10_1)

-- Index : 11, Type : AdventureEventHandle
local node_11 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 11, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_5", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_11)
-- Item Count : 1
local node_11_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Battle", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {12,22,}}
table.insert(node_11.Items, node_11_0)

-- Index : 12, Type : AdventureEventAction
local node_12 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 12, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1020503"}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventEnd
local node_13 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 13, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_13)

-- Index : 14, Type : AdventureEventRandomAction
local node_14 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 14, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_14)
-- Item Count : 2
local node_14_0 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {15,21,}}
table.insert(node_14.Items, node_14_0)
local node_14_1 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {16,}}
table.insert(node_14.Items, node_14_1)

-- Index : 15, Type : AdventureEventHandle
local node_15 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 15, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_4", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_15)
-- Item Count : 1
local node_15_0 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Leave", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {18,}}
table.insert(node_15.Items, node_15_0)

-- Index : 16, Type : AdventureEventHandle
local node_16 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 16, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Text_30119_5", Label = "Event_Option_30121_2", Next = {}, Items = {}}
table.insert(nodes, node_16)
-- Item Count : 1
local node_16_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Battle", Tip = "Event_Combat", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimeDust", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 15, ConditionParam2 = 999, Next = {17,23,}}
table.insert(node_16.Items, node_16_0)

-- Index : 17, Type : AdventureEventAction
local node_17 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 17, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1020503"}
table.insert(nodes, node_17)

-- Index : 18, Type : AdventureEventEnd
local node_18 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 18, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_18)

-- Index : 19, Type : AdventureEventAction
local node_19 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 19, Sort = 99, ActionType = AdventureEventActionType.AddTimedust, Param = "20"}
table.insert(nodes, node_19)

-- Index : 20, Type : AdventureEventAction
local node_20 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 20, Sort = 99, ActionType = AdventureEventActionType.AddTimedust, Param = "50"}
table.insert(nodes, node_20)

-- Index : 21, Type : AdventureEventAction
local node_21 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 21, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30113"}
table.insert(nodes, node_21)

-- Index : 22, Type : AdventureEventEnd
local node_22 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 22, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_22)

-- Index : 23, Type : AdventureEventEnd
local node_23 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 23, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_23)

-- Index : 24, Type : AdventureEventEnd
local node_24 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 24, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_24)

-- Index : 25, Type : AdventureEventHandle
local node_25 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 25, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Result_30119_1", Label = "Event_Continue", Next = {5,19,}, Items = {}}
table.insert(nodes, node_25)

-- Index : 26, Type : AdventureEventHandle
local node_26 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 26, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30119", Content = "Event_Result_30119_3", Label = "Event_Continue", Next = {20,10,}, Items = {}}
table.insert(nodes, node_26)

return nodes
