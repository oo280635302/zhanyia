-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20201", Content = "Event_Text_20201_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 3
local node_2_0 = {Icon = "UI/Adventure/icon_Event_GetHP", Label = "Event_Option_20201_1", Tip = "Event_HPRecover", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {4,3,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_CopyCard", Label = "Event_Option_20201_2", Tip = "Event_CopyCard", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {9,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_RemoveCard", Label = "Event_Option_20201_3", Tip = "Event_RemoveCard", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_2.Items, node_2_2)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 1, ActionType = AdventureEventActionType.AddHP, Param = "5000"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20201", Content = "Event_Result_20201_1", Label = "Event_Continue", Next = {7,8,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "50301"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20201", Content = "Event_Result_20201_3", Label = "Event_Continue", Next = {8,7,5,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventEnd
local node_7 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 7, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 10, ActionType = AdventureEventActionType.Event, Param = "20202"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventHandle
local node_9 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 9, Sort = 10, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_20201", Content = "Event_Result_20201_2", Label = "Event_Continue", Next = {8,7,10,}, Items = {}}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "50303"}
table.insert(nodes, node_10)

return nodes
