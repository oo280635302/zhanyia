-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Text_40202_1", Label = "Event_Option_40202_1", Next = {4,}, Items = {}}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = false,  Unit = "10001", UnitAction = "alert",  Title = "Event_Name_40201_1", Content = "Event_Text_40202_2", Label = "Event_Continue", Next = {}, Items = {}}
table.insert(nodes, node_4)
-- Item Count : 2
local node_4_0 = {Icon = "", Label = "Event_Option_40202_2", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {5,}}
table.insert(node_4.Items, node_4_0)
local node_4_1 = {Icon = "", Label = "Event_Option_40202_3", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {7,6,}}
table.insert(node_4.Items, node_4_1)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Text_40202_3", Label = "Event_Option_40202_3", Next = {7,6,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 1, ActionType = AdventureEventActionType.Event, Param = "40204"}
table.insert(nodes, node_7)

return nodes
