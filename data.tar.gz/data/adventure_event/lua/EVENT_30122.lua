-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30122", Content = "Event_Text_30122_1", Label = "Event_Option_30120_1", Next = {4,}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 3
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30122_1", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {4,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30122_2", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {5,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Option_30122_3", Tip = "Event_BattleWarning", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {7,}}
table.insert(node_2.Items, node_2_2)

-- Index : 3, Type : AdventureEventEnd
local node_3 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 3, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30122", Content = "Event_Result_30122_2", Label = "Event_Battle", Next = {3,9,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30122", Content = "Event_Result_30122_2", Label = "Event_Battle", Next = {3,10,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30122", Content = "Event_Result_30122_3", Label = "Event_Leave", Next = {3,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventRandomAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 7, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_7)
-- Item Count : 2
local node_7_0 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_7.Items, node_7_0)
local node_7_1 = {Weight = 50, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {8,}}
table.insert(node_7.Items, node_7_1)

-- Index : 8, Type : AdventureEventHandle
local node_8 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 8, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30122", Content = "Event_Result_30122_4", Label = "Event_Battle", Next = {11,3,}, Items = {}}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 9, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1010701"}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1010801"}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 99, ActionType = AdventureEventActionType.Fight, Param = "1020602"}
table.insert(nodes, node_11)

return nodes
