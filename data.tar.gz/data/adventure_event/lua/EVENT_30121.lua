-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30121", Content = "Event_Text_30121_1", Label = "Event_Option_30120_1", Next = {3,5,}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 3
local node_2_0 = {Icon = "UI/Adventure/icon_Event_LoseHP", Label = "Event_Option_30121_1", Tip = "Event_HPReduce10", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughHP", ConditionType = AdventureConditionType.LIFE_VALUE, ConditionParam1 = 6, ConditionParam2 = 999, Next = {5,9,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_LoseHP", Label = "Event_Option_30109_1", Tip = "Event_HPReduce20", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughHP", ConditionType = AdventureConditionType.LIFE_VALUE, ConditionParam1 = 11, ConditionParam2 = 999, Next = {6,10,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30121_3", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {7,}}
table.insert(node_2.Items, node_2_2)

-- Index : 3, Type : AdventureEventAction
local node_3 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 3, Sort = 99, ActionType = AdventureEventActionType.AddTimedust, Param = "50"}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30121", Content = "Event_Result_30121_1", Label = "Event_Leave", Next = {4,3,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30121", Content = "Event_Result_30121_2", Label = "Event_Leave", Next = {4,8,3,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30121", Content = "Event_Result_30121_3", Label = "Event_Leave", Next = {4,}, Items = {}}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 99, ActionType = AdventureEventActionType.AddDice, Param = "1"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 9, Sort = 1, ActionType = AdventureEventActionType.ReduceHP_Value, Param = "5"}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 1, ActionType = AdventureEventActionType.ReduceHP_Value, Param = "10"}
table.insert(nodes, node_10)

return nodes
