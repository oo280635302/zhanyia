-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {7,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventAction
local node_2 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 2, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Text_40202_5", Label = "Event_Option_40202_5", Next = {10,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = false,  Unit = "10004", UnitAction = "skill",  Title = "Event_Name_40202_2", Content = "Event_Text_40202_8", Label = "Event_Option_40202_7", Next = {5,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "confused",  Title = "Event_Name_40202_2", Content = "Event_Text_40202_9", Label = "Event_Option_40202_8", Next = {6,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventEnd
local node_6 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 6, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Text_40202_4", Label = "Event_Continue", Next = {3,}, Items = {}}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventHandle
local node_8 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 8, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40202_2", Content = "Event_Text_40202_6", Label = "Event_Continue", Next = {9,}, Items = {}}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventHandle
local node_9 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 9, Sort = 99, ShowHead = true,  Unit = "10004", UnitAction = "idle",  Title = "Event_Name_40202_2", Content = "Event_Text_40202_7", Label = "Event_Option_40202_6", Next = {4,}, Items = {}}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventHandle
local node_10 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 10, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40201_1", Content = "Event_Result_40202_2", Label = "Event_Continue", Next = {8,}, Items = {}}
table.insert(nodes, node_10)

return nodes
