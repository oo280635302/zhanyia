-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {3,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventEnd
local node_2 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 2, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_2)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_40601_1", Content = "Event_Text_40601_1", Label = "Event_Option_40601_1", Next = {4,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 99, ShowHead = false,  Unit = "10005", UnitAction = "attack",  Title = "Event_Name_40601_1", Content = "Event_Text_40601_2", Label = "Event_Continue", Next = {5,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 99, ShowHead = false,  Unit = "10001", UnitAction = "exciting",  Title = "Event_Name_40601_1", Content = "Event_Text_40601_3", Label = "Event_Option_40601_3", Next = {2,}, Items = {}}
table.insert(nodes, node_5)

return nodes
