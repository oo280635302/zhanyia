-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {12,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_40301_1", Content = "Event_Text_40301_2", Label = "Event_Option_40301_1", Next = {3,}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 3
local node_2_0 = {Icon = "", Label = "Event_Option_40301_1", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "", Label = "Event_Option_40301_2", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 1000301, ConditionParam2 = 0, Next = {6,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "", Label = "Event_Option_40301_3", Tip = "", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.FLAG, ConditionParam1 = 1000302, ConditionParam2 = 0, Next = {7,}}
table.insert(node_2.Items, node_2_2)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40301_1", Content = "Event_Result_40301_1", Label = "Event_Continue", Next = {10,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 99, ActionType = AdventureEventActionType.Deck, Param = "30114"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40301_1", Content = "Event_Result_40301_2", Label = "Event_Continue", Next = {8,2,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventHandle
local node_7 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 7, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40301_1", Content = "Event_Result_40301_3", Label = "Event_Continue", Next = {9,2,}, Items = {}}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 10, ActionType = AdventureEventActionType.SetFlag, Param = "1000301"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 9, Sort = 10, ActionType = AdventureEventActionType.SetFlag, Param = "1000302"}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventHandle
local node_10 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 10, Sort = 99, ShowHead = true,  Unit = "10009", UnitAction = "stun",  Title = "Event_Name_40301_1", Content = "Event_Text_40301_3", Label = "Event_Continue", Next = {13,}, Items = {}}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventHandle
local node_11 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 11, Sort = 99, ShowHead = true,  Unit = "10001", UnitAction = "angry",  Title = "Event_Name_40301_2", Content = "Event_Text_40301_5", Label = "Event_Continue", Next = {4,}, Items = {}}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventHandle
local node_12 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 12, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_40301_1", Content = "Event_Text_40301_1", Label = "Event_Continue", Next = {2,}, Items = {}}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventHandle
local node_13 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 13, Sort = 99, ShowHead = true,  Unit = "10007", UnitAction = "cheer",  Title = "Event_Name_40301_1", Content = "Event_Text_40301_4", Label = "Event_Continue", Next = {11,}, Items = {}}
table.insert(nodes, node_13)

return nodes
