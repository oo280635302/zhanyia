-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Text_30107_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30107_1", Tip = "Event_GetDice", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 20, ConditionParam2 = 999, Next = {4,5,12,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30107_4", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {13,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventEnd
local node_3 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 3, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 4, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "20"}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 5, Sort = 2, ActionType = AdventureEventActionType.AddDice, Param = "1"}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Text_30107_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_6)
-- Item Count : 2
local node_6_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30107_2", Tip = "Event_GetDice", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 40, ConditionParam2 = 999, Next = {7,8,14,}}
table.insert(node_6.Items, node_6_0)
local node_6_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30107_4", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {15,}}
table.insert(node_6.Items, node_6_1)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "40"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 2, ActionType = AdventureEventActionType.AddDice, Param = "1"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventHandle
local node_9 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 9, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Text_30107_2", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_9)
-- Item Count : 2
local node_9_0 = {Icon = "UI/Adventure/icon_Event_CostTimedust", Label = "Event_Option_30107_3", Tip = "Event_GetDice", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughTimedust", ConditionType = AdventureConditionType.TIMEDUST, ConditionParam1 = 60, ConditionParam2 = 999, Next = {10,11,17,}}
table.insert(node_9.Items, node_9_0)
local node_9_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30107_4", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {18,}}
table.insert(node_9.Items, node_9_1)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 1, ActionType = AdventureEventActionType.ReduceTimedust, Param = "60"}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 2, ActionType = AdventureEventActionType.AddDice, Param = "1"}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventHandle
local node_12 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 12, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_1", Label = "Event_Continue", Next = {6,}, Items = {}}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventHandle
local node_13 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 13, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_2", Label = "Event_Leave", Next = {3,}, Items = {}}
table.insert(nodes, node_13)

-- Index : 14, Type : AdventureEventHandle
local node_14 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 14, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_1", Label = "Event_Continue", Next = {9,}, Items = {}}
table.insert(nodes, node_14)

-- Index : 15, Type : AdventureEventHandle
local node_15 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 15, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_2", Label = "Event_Leave", Next = {16,}, Items = {}}
table.insert(nodes, node_15)

-- Index : 16, Type : AdventureEventEnd
local node_16 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 16, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_16)

-- Index : 17, Type : AdventureEventHandle
local node_17 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 17, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_5", Label = "Event_Leave", Next = {19,}, Items = {}}
table.insert(nodes, node_17)

-- Index : 18, Type : AdventureEventHandle
local node_18 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 18, Sort = 99, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30107", Content = "Event_Result_30107_2", Label = "Event_Leave", Next = {19,}, Items = {}}
table.insert(nodes, node_18)

-- Index : 19, Type : AdventureEventEnd
local node_19 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 19, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_19)

return nodes
