-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30110", Content = "Event_Text_30110_1", Label = "Event_Option_30121_2", Next = {3,}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 2
local node_2_0 = {Icon = "UI/Adventure/icon_Event_Random", Label = "Event_Dice", Tip = "Event_UseDice", ItemType = AdventureEventItemType.NONE, CTip = "Event_EnoughDice", ConditionType = AdventureConditionType.DICE, ConditionParam1 = 1, ConditionParam2 = 999, Next = {5,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Option_30110_2", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,}}
table.insert(node_2.Items, node_2_1)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30110", Content = "Event_Result_30110_4", Label = "Event_Leave", Next = {4,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventEnd
local node_4 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 4, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventRandomAction
local node_5 = {Type = AdventureEventNodeType.AdventureEventRandomAction, Index = 5, Sort = 99, Next = {}, Items = {}}
table.insert(nodes, node_5)
-- Item Count : 3
local node_5_0 = {Weight = 40, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,4,}}
table.insert(node_5.Items, node_5_0)
local node_5_1 = {Weight = 40, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {7,4,}}
table.insert(node_5.Items, node_5_1)
local node_5_2 = {Weight = 20, ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {8,4,}}
table.insert(node_5.Items, node_5_2)

-- Index : 6, Type : AdventureEventAction
local node_6 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 6, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30124"}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30125"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 99, ActionType = AdventureEventActionType.Event, Param = "30126"}
table.insert(nodes, node_8)

return nodes
