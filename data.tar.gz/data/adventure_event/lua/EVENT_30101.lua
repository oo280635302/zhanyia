-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Text_30101_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 4
local node_2_0 = {Icon = "UI/Adventure/icon_Event_GetRelic", Label = "Event_Option_30101_1", Tip = "Event_GainCardRelic", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {3,7,8,14,15,}}
table.insert(node_2.Items, node_2_0)
local node_2_1 = {Icon = "UI/Adventure/icon_Event_GetRelic", Label = "Event_Option_30101_2", Tip = "Event_GainCardRelic", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {4,9,10,16,17,}}
table.insert(node_2.Items, node_2_1)
local node_2_2 = {Icon = "UI/Adventure/icon_Event_GetRelic", Label = "Event_Option_30101_3", Tip = "Event_GainCardRelic", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {5,11,12,19,18,}}
table.insert(node_2.Items, node_2_2)
local node_2_3 = {Icon = "UI/Adventure/icon_Event_Leave", Label = "Event_Refuse", Tip = "Event_EndEvent", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 0, ConditionParam2 = 0, Next = {6,}}
table.insert(node_2.Items, node_2_3)

-- Index : 3, Type : AdventureEventHandle
local node_3 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 3, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Result_30101_1", Label = "Event_Confirm", Next = {13,}, Items = {}}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventHandle
local node_4 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 4, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Result_30101_2", Label = "Event_Confirm", Next = {13,}, Items = {}}
table.insert(nodes, node_4)

-- Index : 5, Type : AdventureEventHandle
local node_5 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 5, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Result_30101_3", Label = "Event_Confirm", Next = {13,}, Items = {}}
table.insert(nodes, node_5)

-- Index : 6, Type : AdventureEventHandle
local node_6 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 6, Sort = 10, ShowHead = false,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Result_30101_4", Label = "Event_Confirm", Next = {13,}, Items = {}}
table.insert(nodes, node_6)

-- Index : 7, Type : AdventureEventAction
local node_7 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 7, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "30101"}
table.insert(nodes, node_7)

-- Index : 8, Type : AdventureEventAction
local node_8 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 8, Sort = 2, ActionType = AdventureEventActionType.Deck, Param = "30121"}
table.insert(nodes, node_8)

-- Index : 9, Type : AdventureEventAction
local node_9 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 9, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "30102"}
table.insert(nodes, node_9)

-- Index : 10, Type : AdventureEventAction
local node_10 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 10, Sort = 2, ActionType = AdventureEventActionType.Deck, Param = "30122"}
table.insert(nodes, node_10)

-- Index : 11, Type : AdventureEventAction
local node_11 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 11, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "30103"}
table.insert(nodes, node_11)

-- Index : 12, Type : AdventureEventAction
local node_12 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 12, Sort = 2, ActionType = AdventureEventActionType.Deck, Param = "30123"}
table.insert(nodes, node_12)

-- Index : 13, Type : AdventureEventEnd
local node_13 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 13, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_13)

-- Index : 14, Type : AdventureEventAction
local node_14 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 14, Sort = 3, ActionType = AdventureEventActionType.SetFlag, Param = "20001"}
table.insert(nodes, node_14)

-- Index : 15, Type : AdventureEventAction
local node_15 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 15, Sort = 4, ActionType = AdventureEventActionType.SetFlag, Param = "20004"}
table.insert(nodes, node_15)

-- Index : 16, Type : AdventureEventAction
local node_16 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 16, Sort = 3, ActionType = AdventureEventActionType.SetFlag, Param = "20002"}
table.insert(nodes, node_16)

-- Index : 17, Type : AdventureEventAction
local node_17 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 17, Sort = 4, ActionType = AdventureEventActionType.SetFlag, Param = "20004"}
table.insert(nodes, node_17)

-- Index : 18, Type : AdventureEventAction
local node_18 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 18, Sort = 4, ActionType = AdventureEventActionType.SetFlag, Param = "20004"}
table.insert(nodes, node_18)

-- Index : 19, Type : AdventureEventAction
local node_19 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 19, Sort = 3, ActionType = AdventureEventActionType.SetFlag, Param = "20003"}
table.insert(nodes, node_19)

return nodes
