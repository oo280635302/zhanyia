-- Generate By AdventureLuaExporter 
require("AdventureEvent/AdventureEventCommon")
local nodes = {}
-- Index : 1, Type : AdventureEventStart
local node_1 = {Type = AdventureEventNodeType.AdventureEventStart, Index = 1, Sort = 99, Pre = -1, Next = {2,}}
table.insert(nodes, node_1)

-- Index : 2, Type : AdventureEventHandle
local node_2 = {Type = AdventureEventNodeType.AdventureEventHandle, Index = 2, Sort = 99, ShowHead = true,  Unit = "", UnitAction = "",  Title = "Event_Name_30101", Content = "Event_Text_30105_1", Label = "", Next = {}, Items = {}}
table.insert(nodes, node_2)
-- Item Count : 1
local node_2_0 = {Icon = "UI/Adventure/icon_Event_RemoveCard", Label = "Event_Leave", Tip = "Event_RemoveCurseCard", ItemType = AdventureEventItemType.NONE, CTip = "", ConditionType = AdventureConditionType.NONE, ConditionParam1 = 10, ConditionParam2 = 9999, Next = {4,3,}}
table.insert(node_2.Items, node_2_0)

-- Index : 3, Type : AdventureEventEnd
local node_3 = {Type = AdventureEventNodeType.AdventureEventEnd, Index = 3, Sort = 99, Pre = -1, Next = nil}
table.insert(nodes, node_3)

-- Index : 4, Type : AdventureEventAction
local node_4 = {Type = AdventureEventNodeType.AdventureEventAction, Index = 4, Sort = 1, ActionType = AdventureEventActionType.Deck, Param = "30106"}
table.insert(nodes, node_4)

return nodes
